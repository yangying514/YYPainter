//
//  zI01xsq_yrpwr_communityViewController.h
//  zI01xsq_yrpwr_community
//
//  Created by Apple on 2018/10/31.
//  Copyright © 2018年 xiqi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface zI01xsq_yrpwr_rootViewController : UIViewController
+ (void)test;
@end
